#include <iostream>
#include "cmdline.h"
#include "Expr.h"

int main(int argc, const char * argv[]) {
    useArgs(argc, argv);
    return 0;
}


